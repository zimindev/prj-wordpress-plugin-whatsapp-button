<?php
/*
 * Plugin Name: WhatsApp Button
 * Plugin URI: https://zimin.dev/
 * Description: Plugin for fast contact in WhatsApp
 * Author: Sasha Zimin
 * Author URI: https://zimin.dev/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Version: 1.1
 * Requires at least: 1.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

// Admin Settings Menu
function wb_register_settings_menu() {
    add_options_page('WhatsApp Button Settings', 'WhatsApp Button', 'manage_options', 'whatsapp-button', 'wb_settings_page');
}
add_action('admin_menu', 'wb_register_settings_menu');

function wb_settings_page() {
    ?>
    <div class="wrap">
        <h1>WhatsApp Button Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('wb_settings_group');
            do_settings_sections('wb_settings_group');
            ?>
            <table class="form-table">
                <tr valign="top">
                <th scope="row">WhatsApp Phone Number</th>
                <td><input type="text" name="wb_phone_number" value="<?php echo esc_attr(get_option('wb_phone_number')); ?>" placeholder="e.g. 1234567890" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

function wb_register_settings() {
    register_setting('wb_settings_group', 'wb_phone_number');
}
add_action('admin_init', 'wb_register_settings');

// Frontend Button
function wb_add_whatsapp_button() {
    $phone = preg_replace('/\D/', '', get_option('wb_phone_number'));
    if (!$phone) return;

    echo '
    <a href="https://wa.me/' . esc_attr($phone) . '" target="_blank" class="wb-float" title="Chat on WhatsApp">
        <img src="https://img.icons8.com/color/48/000000/whatsapp--v1.png" alt="WhatsApp">
    </a>
    <style>
        .wb-float {
            position: fixed;
            width: 60px;
            height: 60px;
            bottom: 20px;
            right: 20px;
            background-color: #25D366;
            color: #FFF;
            border-radius: 50px;
            text-align: center;
            font-size: 30px;
            box-shadow: 0px 2px 3px #999;
            z-index: 1000;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .wb-float img {
            width: 32px;
            height: 32px;
        }
    </style>
    ';
}
add_action('wp_footer', 'wb_add_whatsapp_button');
